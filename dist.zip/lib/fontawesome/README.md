# Font Awesome 5.0.8

Thanks for downloading Font Awesome! We're so excited you're here.

Our documentation is available online. Just head here:

https://fontawesome.com
